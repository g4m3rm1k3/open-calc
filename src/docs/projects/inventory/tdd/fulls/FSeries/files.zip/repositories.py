class PostRepository:
    def __init__(self, conn):
        self.conn = conn

    def create(self, author_id: int, content: str) -> dict:
        cursor = self.conn.execute(
            "INSERT INTO posts (author_id, content) VALUES (?, ?)",
            (author_id, content),
        )
        self.conn.commit()
        return {"id": cursor.lastrowid, "author_id": author_id, "content": content}

    def get_by_id(self, post_id: int):
        return self.conn.execute(
            "SELECT * FROM posts WHERE id = ?", (post_id,)
        ).fetchone()

    def can_modify(self, post_id: int, member_id: int, role: str) -> tuple[bool, str | None]:
        row = self.get_by_id(post_id)
        if row is None:
            return False, "not_found"
        if row["author_id"] != member_id and role != "admin":
            return False, "forbidden"
        return True, None

    def update_content(self, post_id: int, content: str) -> None:
        self.conn.execute(
            "UPDATE posts SET content = ? WHERE id = ?", (content, post_id)
        )
        self.conn.commit()

    def delete(self, post_id: int) -> None:
        self.conn.execute("DELETE FROM posts WHERE id = ?", (post_id,))
        self.conn.commit()
