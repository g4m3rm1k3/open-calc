from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import declarative_base

Base = declarative_base()


class Member(Base):
    __tablename__ = "members"
    id = Column(Integer, primary_key=True)
    username = Column(String, nullable=False, unique=True)
    role = Column(String, nullable=False, default="member")

# Note: only `members` is modeled here, deliberately (Lesson 17) — the rest of the
# schema is still managed directly through db.py's raw SQL. Model additional tables
# here only as they actually need an Alembic-managed migration.
