import sqlite3

DB_PATH = "social.db"


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")  # Lesson 24
    return conn


def init_db_schema(conn):
    """Schema only, no seed data — used directly by the test fixture (Lesson 18)."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS members (
            id INTEGER PRIMARY KEY,
            username TEXT NOT NULL UNIQUE,
            role TEXT NOT NULL DEFAULT 'member'
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS credentials (
            member_id INTEGER PRIMARY KEY,
            password_hash TEXT NOT NULL,
            FOREIGN KEY (member_id) REFERENCES members(id)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS bios (
            member_id INTEGER,
            text TEXT NOT NULL,
            FOREIGN KEY (member_id) REFERENCES members(id)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS posts (
            id INTEGER PRIMARY KEY,
            author_id INTEGER NOT NULL,
            content TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            like_count INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (author_id) REFERENCES members(id)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS comments (
            id INTEGER PRIMARY KEY,
            post_id INTEGER NOT NULL,
            author_id INTEGER NOT NULL,
            content TEXT NOT NULL CHECK (length(content) > 0),
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY (post_id) REFERENCES posts(id),
            FOREIGN KEY (author_id) REFERENCES members(id)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS likes (
            post_id INTEGER NOT NULL,
            member_id INTEGER NOT NULL,
            PRIMARY KEY (post_id, member_id),
            FOREIGN KEY (post_id) REFERENCES posts(id),
            FOREIGN KEY (member_id) REFERENCES members(id)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS follows (
            follower_id INTEGER NOT NULL,
            followed_id INTEGER NOT NULL,
            PRIMARY KEY (follower_id, followed_id),
            CHECK (follower_id != followed_id),
            FOREIGN KEY (follower_id) REFERENCES members(id),
            FOREIGN KEY (followed_id) REFERENCES members(id)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS hashtags (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL UNIQUE
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS post_hashtags (
            post_id INTEGER NOT NULL,
            hashtag_id INTEGER NOT NULL,
            PRIMARY KEY (post_id, hashtag_id),
            FOREIGN KEY (post_id) REFERENCES posts(id),
            FOREIGN KEY (hashtag_id) REFERENCES hashtags(id)
        )
    """)

    conn.execute("CREATE INDEX IF NOT EXISTS idx_members_username ON members(username)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_post_hashtags_hashtag ON post_hashtags(hashtag_id)")

    conn.execute("""
        CREATE VIEW IF NOT EXISTS post_rankings AS
        SELECT
            posts.id,
            posts.content,
            members.username AS author,
            posts.like_count,
            RANK() OVER (PARTITION BY posts.author_id ORDER BY posts.like_count DESC) AS rank_within_author
        FROM posts
        JOIN members ON posts.author_id = members.id
    """)
    conn.commit()


def init_db():
    """Schema + seed data — used for local/dev running (not by tests, see Lesson 18)."""
    conn = get_connection()
    init_db_schema(conn)
    conn.execute("INSERT OR IGNORE INTO members (id, username) VALUES (1, 'ada')")
    conn.execute("INSERT OR IGNORE INTO members (id, username) VALUES (2, 'grace')")
    conn.execute(
        "INSERT OR IGNORE INTO bios (rowid, member_id, text) VALUES (1, 1, 'Mathematician and programmer.')"
    )
    conn.commit()
    conn.close()
