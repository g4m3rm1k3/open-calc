# PROJECT STATE — Developer Social Network Curriculum

**How to use this file:** paste this entire document into a new chat, along with `bootstrap-prompt-v2.md` (the Master Lesson Schema). Say "continue the curriculum from this state." That's the complete handoff — nothing else should be needed.

This file should be regenerated at the end of any future lesson-generation session, replacing the version below. It is NOT a static document — it grows/changes as new phases (e.g. frontend) get added. See "How this file changes" at the bottom.

---

## Status

Backend curriculum (24 lessons + 4 interludes) is **complete**. Next planned phase: frontend (React + TypeScript), not yet started. See "Known Gaps" and "Next Phase" below before starting it.

## Complete Terminology Ledger

*(Every term taught, in order — a new chat must treat anything below as already explained; do not re-explain, do not use anything not listed without explaining it first.)*

**Lesson 1:** Request/response cycle, `FastAPI()` app object, decorator (`@app.get`), inversion of control, Python type annotations (unenforced), Pydantic `BaseModel`, `response_model`, static vs dynamic typing, TestClient

**Interlude A:** Stack frame, call stack, heap, reference, aliasing, `id()`, defensive copying

**Lesson 2:** Volatile/non-volatile storage, SQL, connection, `row_factory`, `SELECT`, `CREATE TABLE IF NOT EXISTS`, `INSERT OR IGNORE`, separation of concerns

**Lesson 3:** Route/path parameter, parameter type coercion, `WHERE`, `.fetchone()`, `HTTPException`, foreign key (cross-table), `JOIN`, normalization

**Lesson 4:** Request body, input/output schema split, `Field(min_length=...)`, `INSERT`, `cursor.lastrowid`, `201 Created`, idempotency, trust boundary

**Lesson 5:** `DEFAULT` (column), `ORDER BY`/`ASC`/`DESC`, one-to-many cardinality, query parameter, `LIMIT`/`OFFSET`, bounded vs unbounded query

**Lesson 6:** `PUT`, `UPDATE`/`cursor.rowcount`, `403` vs `404`, authorization vs authentication, `DELETE`, `204 No Content`

**Interlude C:** Stack trace, stack unwinding, bisection debugging, hypothesis-first debugging

**Lesson 7:** Multi-way JOIN, table alias, `CHECK` constraint, defense in depth, nested Pydantic models, object-relational impedance mismatch

**Lesson 8:** Many-to-many cardinality, junction table, composite primary key, `409 Conflict`, transaction/`BEGIN`/`commit`/`rollback`, atomicity, denormalization

**Lesson 9:** Self-referencing junction table, directed graph, in-edges/out-edges, role-based column naming

**Interlude B:** O(n)/linear search, hash function, collision, chaining, O(1) average case, B-tree (index) — *corrects Lesson 3's "similar in spirit" phrasing: SQLite indexes are B-trees (O(log n)), not hash maps (O(1))*

**Lesson 10:** `LIKE`/`%` wildcard, `EXPLAIN QUERY PLAN`, `SCAN` vs `SEARCH`, `CREATE INDEX`, debouncing

**Lesson 11:** Regular expression (regex), pure function, get-or-create (race-safe), normalization at scale

**Lesson 12:** Composite index column order, implicit index (from `UNIQUE`), join chain cost

**Lesson 13:** One-way (cryptographic) function, rainbow table, salt, `bcrypt`, work factor

**Lesson 14:** Uniform failure response, JWT, signing vs. encryption, `exp` claim, stateless authentication, `Header(...)`, `Depends()` for identity

**Lesson 15:** RBAC, combined authorization (ownership OR role), principle of least privilege

**Interlude D:** Reference counting, reference cycle, garbage collector, memory leak, use-after-free

**Lesson 16:** Repository pattern, encapsulation, generator-based dependency (`yield` in `Depends()`), Dependency Inversion Principle

**Lesson 17:** ORM, declarative vs. imperative, Alembic, migration (`upgrade`/`downgrade`), batch table rebuild

**Lesson 18:** Fixture, `dependency_overrides`, mock (`MagicMock`), unit test vs. integration test

**Lesson 19:** Aggregate function (`COUNT`), `GROUP BY`, inner join (named retroactively), `LEFT JOIN`, `COALESCE`, CTE for non-recursive staging

**Lesson 20:** Subquery, uncorrelated subquery, correlated subquery, `EXISTS`/`NOT EXISTS`

**Lesson 21:** Window function (`OVER`, `PARTITION BY`), `RANK()`, chained/composed dependency, view (`CREATE VIEW`), materialized view (contrast)

**Lesson 22:** Global exception handler, fail-safe default, `async def` (named, not fully explained — deferred), logging levels, `exc_info=True`, log handler vs. log call

**Lesson 23:** Decorator (fully explained), `*args, **kwargs`, `functools.wraps`, stacked decorators, cache/TTL, staleness, space-time tradeoff

**Lesson 24:** Docker image/container, layer caching, WAL, checkpoint, WAL-aware backup, deployment ordering

## Final API Manifest

```
GET    /                              -> HomepageResponse
GET    /members                       -> list[Member]
GET    /members/{id}                  -> Member | 404
GET    /members/{id}/profile          -> Profile (joined bio) | 404
POST   /accounts                      -> Member, 201 | 409 duplicate username
POST   /login                         -> TokenResponse | 401
POST   /posts                         -> PostRead, 201 [auth required]
GET    /posts/{id}                    -> PostDetail (nested comments, like_count) | 404
PUT    /posts/{id}                    -> PostRead [auth + ownership/admin]
DELETE /posts/{id}                    -> 204 [auth + ownership/admin]
GET    /feed?limit=&offset=           -> list[FeedPost]
POST   /posts/{id}/comments           -> CommentRead, 201
GET    /posts/{id}/comments           -> list[CommentRead]
POST   /posts/{id}/likes              -> {"liked": true}, 201 | 409 [auth required]
GET    /members/{id}/following        -> list[FollowedMember]
GET    /members/{id}/followers        -> list[FollowedMember]
POST   /members/{id}/follow           -> {"following": true}, 201 | 409 | 422 [auth required]
GET    /members/search?q=             -> list[Member]
GET    /hashtags/{name}/posts         -> list[FeedPost]
GET    /trending                      -> list[FeedPost] [cached 30s]
GET    /recommendations               -> list[FeedPost] [auth required, personalized]
GET    /admin/analytics               -> ranked post list [admin only]
```

## Final Schema State

Tables: `members`, `credentials`, `bios`, `posts`, `comments`, `likes`, `follows`, `hashtags`, `post_hashtags`
Indexes: `idx_members_username`, `idx_post_hashtags_hashtag` (plus implicit indexes from every `UNIQUE`/`PRIMARY KEY`)
View: `post_rankings` (window-function ranking, Lesson 21)
`members.username` UNIQUE, applied via Alembic migration (Lesson 17), not raw SQL
WAL mode enabled (Lesson 24)

## Dependencies

`fastapi`, `uvicorn`, `pydantic`, `pytest`, `httpx`, `bcrypt`, `pyjwt`, `sqlalchemy`, `alembic`

## Known Gaps — flagged honestly, not yet built

- `SECRET_KEY` is hardcoded in `main.py` (Lesson 14) — needs environment-based config before any real deployment
- No CORS configuration — will block a separate frontend immediately
- No refresh tokens — 24h JWT expiry with no renewal path
- No rate limiting — `/login` is currently guessable-password-attack-able
- No CI/CD — Docker exists, nothing automates build/test/deploy
- `like_post` and `follow_member` were assigned as *exercises* to migrate to `Depends(get_current_member)` in Lessons 14/15's lesson text — confirm this was actually done before treating the API manifest above as ground truth

## Next Phase (not started)

Frontend track: React + TypeScript, using shadcn/ui as the design system (chosen specifically because [[user]] doesn't want to hand-design UI from scratch — a component library standardizes that). Plan discussed but not committed: build frontend and backend as two parallel tracks rather than strict interleaving, syncing at phase boundaries rather than lesson-by-lesson. Config/secrets and CORS should be fixed before frontend work begins, since the frontend will hit both immediately.

## How this file changes

Regenerate this file after finishing any further phase (e.g., after finishing frontend lessons). Additions needed at that point: a frontend Terminology Ledger section, a frontend file tree, and how frontend routes map to the backend API Manifest above. The backend sections above stay frozen once backend work is done — only append, don't rewrite them, unless the backend itself is revisited.
