from pydantic import BaseModel, Field


class HomepageResponse(BaseModel):
    message: str


class Member(BaseModel):
    id: int
    username: str


class Profile(BaseModel):
    id: int
    username: str
    bio: str


class PostCreate(BaseModel):
    content: str = Field(min_length=1)  # author_id removed in Lesson 14 — comes from auth, not the client


class PostRead(BaseModel):
    id: int
    author_id: int
    content: str


class PostUpdate(BaseModel):
    content: str = Field(min_length=1)  # editor_id removed in Lesson 15


class FeedPost(BaseModel):
    id: int
    content: str
    username: str
    created_at: str


class PostDetail(BaseModel):
    id: int
    content: str
    like_count: int
    comments: list["CommentRead"]


class CommentCreate(BaseModel):
    content: str = Field(min_length=1)  # author_id removed — comes from auth


class CommentRead(BaseModel):
    id: int
    content: str
    username: str
    created_at: str


class FollowedMember(BaseModel):
    id: int
    username: str


class AccountCreate(BaseModel):
    username: str
    password: str = Field(min_length=8)


class LoginRequest(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str


PostDetail.model_rebuild()
